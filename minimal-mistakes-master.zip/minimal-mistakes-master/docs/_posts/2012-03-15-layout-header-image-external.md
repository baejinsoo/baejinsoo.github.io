---
title: "Layout: Header Image (External URL)"
header:
  image: https://live.staticflickr.com/8084/8396909762_813a2b1829_h.jpg
categories:
  - Layout
  - Uncategorized
tags:
  - edge case
  - featured image
  - image
  - layout
---

This post should display a **header image**, if the theme supports it.

Featured image is an external asset and should load.